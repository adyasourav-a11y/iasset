package com.imexolutions.iasset

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class IAssetApplication : Application()
