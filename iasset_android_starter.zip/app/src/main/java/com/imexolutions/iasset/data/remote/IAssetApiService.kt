package com.imexolutions.iasset.data.remote

import com.imexolutions.iasset.domain.model.PlantSummary
import com.imexolutions.iasset.domain.model.Ticket
import retrofit2.http.GET
import retrofit2.http.Path

interface IAssetApiService {
    @GET("api/v1/plants/{plantId}/generation/summary")
    async suspend fun getPlantSummary(@Path("plantId") plantId: String): PlantSummary

    @GET("api/v1/plants/{plantId}/tickets")
    async suspend fun getTickets(@Path("plantId") plantId: String): List<Ticket>
}
