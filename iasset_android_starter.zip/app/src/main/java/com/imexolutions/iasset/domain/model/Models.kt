package com.imexolutions.iasset.domain.model

data class PlantSummary(
    val plantId: String,
    val plantName: String,
    val capacityKwp: Double,
    val status: String,
    val currentPowerKw: Double,
    val energyTodayKwh: Double,
    val energyLifetimeKwh: Double,
    val performanceRatioPercent: Double,
    val financialSavingsToday: Double,
    val co2AvoidedKg: Double
)

data class Ticket(
    val id: String,
    val ticketNumber: String,
    val category: String,
    val title: String,
    val status: String,
    val createdAt: String
)
