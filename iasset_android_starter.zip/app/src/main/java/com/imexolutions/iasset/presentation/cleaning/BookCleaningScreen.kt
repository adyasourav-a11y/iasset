package com.imexolutions.iasset.presentation.cleaning

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.imexolutions.iasset.presentation.theme.ImexGraphite
import com.imexolutions.iasset.presentation.theme.ImexTealPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookCleaningScreen(
    onNavigateBack: () -> Unit
) {
    var hasWater by remember { mutableStateOf(true) }
    var hasLadder by remember { mutableStateOf(true) }
    var selectedSlot by remember { mutableStateOf("Morning (07:00 - 09:00 AM)") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Book Module Washing") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Preferred Wash Time Slot", fontWeight = FontWeight.SemiBold, color = ImexGraphite)
            val slots = listOf("Morning (07:00 - 09:00 AM)", "Late Afternoon (04:30 - 06:30 PM)")
            slots.forEach { slot ->
                Row(modifier = Modifier.fillMaxWidth()) {
                    RadioButton(
                        selected = selectedSlot == slot,
                        onClick = { selectedSlot = slot }
                    )
                    Text(text = slot, modifier = Modifier.padding(top = 12.dp))
                }
            }

            Divider()

            Text("Site Logistics Confirmation", fontWeight = FontWeight.SemiBold, color = ImexGraphite)
            Row {
                Checkbox(checked = hasWater, onCheckedChange = { hasWater = it })
                Text("Rooftop pressurized water connection available", modifier = Modifier.padding(top = 12.dp))
            }
            Row {
                Checkbox(checked = hasLadder, onCheckedChange = { hasLadder = it })
                Text("Safe roof access & ladder open for technicians", modifier = Modifier.padding(top = 12.dp))
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = onNavigateBack,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ImexTealPrimary)
            ) {
                Text("Confirm Cleaning Booking", fontWeight = FontWeight.Bold)
            }
        }
    }
}
