package com.imexolutions.iasset.presentation.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.imexolutions.iasset.presentation.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onRaiseComplaintClick: () -> Unit,
    onBookCleaningClick: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(ImexGraphite, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(6.dp).background(ImexTealPrimary, CircleShape))
                                Spacer(modifier = Modifier.height(2.dp))
                                Box(modifier = Modifier.width(5.dp).height(13.dp).background(ImexTealPrimary, RoundedCornerShape(2.dp)))
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(text = "i", fontSize = 24.sp, fontWeight = FontWeight.Black, color = ImexTealPrimary)
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(text = "ASSET", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = ImexGraphite, letterSpacing = 1.2.sp)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Notifications, contentDescription = "Alerts", tint = ImexGraphite)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Live Power Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = ImexTealContainer),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Live Power Output",
                            style = MaterialTheme.typography.titleMedium,
                            color = ImexOnTealContainer
                        )
                        Badge(containerColor = StatusOnlineGreen) {
                            Text(text = "ONLINE", color = Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "84.2 kW",
                        fontSize = 42.sp,
                        fontWeight = FontWeight.Black,
                        color = ImexOnTealContainer
                    )
                    Text(
                        text = "Installed Capacity: 100 kWp | Huawei SUN2000",
                        style = MaterialTheme.typography.bodySmall,
                        color = ImexOnTealContainer.copy(alpha = 0.8f)
                    )
                }
            }

            // Quick Stats Grid
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(
                    title = "Today's Energy",
                    value = "432.8 kWh",
                    icon = Icons.Default.WbSunny,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "Savings Today",
                    value = "$64.92",
                    icon = Icons.Default.Savings,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MetricCard(
                    title = "Performance Ratio",
                    value = "82.4%",
                    icon = Icons.Default.Speed,
                    modifier = Modifier.weight(1f)
                )
                MetricCard(
                    title = "CO₂ Avoided",
                    value = "355 kg",
                    icon = Icons.Default.Eco,
                    modifier = Modifier.weight(1f)
                )
            }

            // Soiling Alert Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = StatusSoilingOrange)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Soiling Detected (~13%)", fontWeight = FontWeight.Bold, color = StatusSoilingOrange)
                        Text(text = "Dust derate observed. Wash recommended.", fontSize = 12.sp)
                    }
                    Button(
                        onClick = onBookCleaningClick,
                        colors = ButtonDefaults.buttonColors(containerColor = StatusSoilingOrange),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Clean")
                    }
                }
            }

            // Action Buttons
            Text(
                text = "Operations & Maintenance Support",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = ImexGraphite
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = onRaiseComplaintClick,
                    modifier = Modifier.weight(1f).height(54.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.ReportProblem, contentDescription = null, tint = StatusFaultRed)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Report Fault", color = StatusFaultRed)
                }

                Button(
                    onClick = onBookCleaningClick,
                    modifier = Modifier.weight(1f).height(54.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = ImexTealPrimary)
                ) {
                    Icon(Icons.Default.CleaningServices, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Book Cleaning")
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = ImexGraphiteSurface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Icon(icon, contentDescription = null, tint = ImexTealPrimary)
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = title, fontSize = 12.sp, color = Color.Gray)
            Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = ImexGraphite)
        }
    }
}
