package com.imexolutions.iasset.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.imexolutions.iasset.presentation.auth.LoginOtpScreen
import com.imexolutions.iasset.presentation.cleaning.BookCleaningScreen
import com.imexolutions.iasset.presentation.dashboard.DashboardScreen
import com.imexolutions.iasset.presentation.splash.SplashScreen
import com.imexolutions.iasset.presentation.ticketing.RaiseComplaintScreen

@Composable
fun IAssetNavGraph(
    navController: NavHostController = rememberNavController()
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(
                onSplashFinished = {
                    navController.navigate(Screen.Dashboard.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            )
        }
        composable(Screen.Login.route) {
            LoginOtpScreen(
                onLoginSuccess = {
                    navController.navigate(Screen.Dashboard.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }
            )
        }
        composable(Screen.Dashboard.route) {
            DashboardScreen(
                onRaiseComplaintClick = { navController.navigate(Screen.RaiseComplaint.route) },
                onBookCleaningClick = { navController.navigate(Screen.BookCleaning.route) }
            )
        }
        composable(Screen.RaiseComplaint.route) {
            RaiseComplaintScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
        composable(Screen.BookCleaning.route) {
            BookCleaningScreen(
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }
}
