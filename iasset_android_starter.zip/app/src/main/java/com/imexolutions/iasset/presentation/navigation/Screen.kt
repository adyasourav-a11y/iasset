package com.imexolutions.iasset.presentation.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Dashboard : Screen("dashboard")
    object RaiseComplaint : Screen("raise_complaint")
    object BookCleaning : Screen("book_cleaning")
    object TicketList : Screen("ticket_list")
}
