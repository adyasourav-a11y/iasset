package com.imexolutions.iasset.presentation.splash

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.imexolutions.iasset.R
import com.imexolutions.iasset.presentation.theme.ImexGraphite
import com.imexolutions.iasset.presentation.theme.ImexTealPrimary
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onSplashFinished: () -> Unit
) {
    LaunchedEffect(Unit) {
        delay(2200)
        onSplashFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterVertically,
            verticalArrangement = Arrangement.Center
        ) {
            // Imexolutions 'i' Icon
            Image(
                painter = painterResource(id = R.drawable.ic_iasset_logo),
                contentDescription = "i ASSET Logo",
                modifier = Modifier.size(96.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // i ASSET Wordmark
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = "i",
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Black,
                    color = ImexTealPrimary
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "ASSET",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = ImexGraphite,
                    letterSpacing = 2.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "SOLAR ASSET INTELLIGENCE & O&M",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.Gray,
                letterSpacing = 1.5.sp
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Imexolutions Subtitle
            Text(
                text = "POWERING INDUSTRIES | TOTAL ENERGY SOLUTIONS",
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = ImexTealPrimary,
                letterSpacing = 1.sp
            )
        }
    }
}
