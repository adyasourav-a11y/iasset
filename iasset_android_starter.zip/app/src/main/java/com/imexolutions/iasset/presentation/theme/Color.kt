package com.imexolutions.iasset.presentation.theme

import androidx.compose.ui.graphics.Color

// Imexolutions Brand Color Tokens
val ImexTealPrimary = Color(0xFF1CB7BB)
val ImexTealDark = Color(0xFF0E8E91)
val ImexTealContainer = Color(0xFFE0F7F7)
val ImexOnTealContainer = Color(0xFF004F52)

val ImexGraphite = Color(0xFF444243)
val ImexGraphiteDark = Color(0xFF2D2B2C)
val ImexGraphiteSurface = Color(0xFFF4F5F6)

// Solar Performance & Operational Accents
val SolarAmber = Color(0xFFF59E0B)
val StatusOnlineGreen = Color(0xFF10B981)
val StatusFaultRed = Color(0xFFEF4444)
val StatusSoilingOrange = Color(0xFFF97316)

val BackgroundLight = Color(0xFFF8FAFA)
val SurfaceLight = Color(0xFFFFFFFF)
