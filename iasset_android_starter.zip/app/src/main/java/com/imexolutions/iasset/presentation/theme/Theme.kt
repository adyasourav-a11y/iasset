package com.imexolutions.iasset.presentation.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = ImexTealPrimary,
    onPrimary = Color.White,
    primaryContainer = ImexTealContainer,
    onPrimaryContainer = ImexOnTealContainer,
    secondary = ImexGraphite,
    onSecondary = Color.White,
    secondaryContainer = ImexGraphiteSurface,
    onSecondaryContainer = ImexGraphiteDark,
    background = BackgroundLight,
    surface = SurfaceLight,
    onBackground = ImexGraphiteDark,
    onSurface = ImexGraphiteDark,
    error = StatusFaultRed,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = ImexTealPrimary,
    onPrimary = ImexGraphiteDark,
    primaryContainer = ImexTealDark,
    onPrimaryContainer = ImexTealContainer,
    secondary = Color(0xFFB0B0B0),
    onSecondary = ImexGraphiteDark,
    secondaryContainer = ImexGraphite,
    onSecondaryContainer = Color.White,
    background = Color(0xFF1A1A1A),
    surface = Color(0xFF242424),
    onBackground = Color.White,
    onSurface = Color.White,
    error = StatusFaultRed,
    onError = Color.White
)

@Composable
fun IAssetTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
